package com.application.demo.salestax.service;

/**
 * @author Vignesh
 * @version 1 
 * TaxCalculationService calculates tax
 */
public interface TaxCalculationService {

	/**
	 * calculateTax calculates total tax for each item
	 * 
	 * @param itemName
	 * @param itemCount
	 * @param originalPrice
	 * @param itemFlag
	 * @return tax
	 */
	public float calculateTax(String itemName, String itemCount, String originalPrice, boolean itemFlag);

	/**
	 * getSalesTax retrieves total salesTax
	 * 
	 * @return salesTax
	 */
	public float getSalesTax();
}
