package com.application.demo.salestax.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.application.demo.salestax.enums.ItemsPojo;

/**
 * 
 * @author Vignesh
 * @version 1 
 * ItemManagementServiceImpl implements ItemManagementService
 */
@Component
public class ItemManagementServiceImpl implements ItemManagementService {

	@Autowired
	private TaxCalculationService taxCalculationService;
	private static final String HYPHEN = "-";
	private static final String SPACE = " ";
	private static final String COLON = ":";
	private static final String COMMA = ",";
	private static final String TOTAL_SALES_TAX = "totalSalesTax";
	private static final String TOTAL_COST = "totalCost";
	private static final String SALES_TAX = " and Sales Tax";
	private static final String TOTAL = "Total";
	private static final String EMPTY = "Empty. Please Check the Tickboxes To Order";
	private static final int ZERO = 0;
	private static final int ONE = 1;
	private static final int TWO = 2;
	private float totalCost;

	@Override
	public Map<String, String> getLocalGoodsDetails(ItemsPojo itemDetails) {
		Map<String, String> localGoodsMap = new HashMap<>();
		localGoodsMap.put(GoodsTypeEnum.BOOK.getItemName(),
				buildGoodsDetails(itemDetails.getBookCount(), itemDetails.getBook(), itemDetails.getBookPrice()));
		localGoodsMap.put(GoodsTypeEnum.CHOCOLATE.getItemName(), buildGoodsDetails(itemDetails.getChocolateBlockCount(),
				itemDetails.getChocolateBlock(), itemDetails.getChocolateBlockPrice()));
		localGoodsMap.put(GoodsTypeEnum.MUSIC_CD.getItemName(), buildGoodsDetails(itemDetails.getMusicCdCount(),
				itemDetails.getMusicCd(), itemDetails.getMusicCdPrice()));
		localGoodsMap.put(GoodsTypeEnum.PERFUME.getItemName(), buildGoodsDetails(itemDetails.getPerfumeCount(),
				itemDetails.getPerfume(), itemDetails.getPerfumePrice()));
		localGoodsMap.put(GoodsTypeEnum.PILLS.getItemName(), buildGoodsDetails(itemDetails.getHeadAchePillsCount(),
				itemDetails.getHeadAchePills(), itemDetails.getHeadAchePillsPrice()));
		return localGoodsMap;
	}

	@Override
	public Map<String, String> getImportedGoodsDetails(ItemsPojo itemDetails) {
		Map<String, String> importedGoodsMap = new HashMap<>();
		importedGoodsMap.put(GoodsTypeEnum.IMP_BOOK.getItemName(), buildGoodsDetails(itemDetails.getImportedBookCount(),
				itemDetails.getImportedBook(), itemDetails.getImportedBookPrice()));
		importedGoodsMap.put(GoodsTypeEnum.IMP_CHOCOLATE.getItemName(),
				buildGoodsDetails(itemDetails.getImportedChocolateBlockCount(), itemDetails.getImportedChocolateBlock(),
						itemDetails.getImportedChocolateBlockPrice()));
		importedGoodsMap.put(GoodsTypeEnum.IMP_PILLS.getItemName(),
				buildGoodsDetails(itemDetails.getImportedHeadAchePillsCount(), itemDetails.getImportedHeadAchePills(),
						itemDetails.getImportedHeadAchePillsPrice()));
		importedGoodsMap.put(GoodsTypeEnum.IMP_PERFUME.getItemName(),
				buildGoodsDetails(itemDetails.getImportedPerfumeCount(), itemDetails.getImportedPerfume(),
						itemDetails.getImportedPerfumePrice()));
		importedGoodsMap.put(GoodsTypeEnum.IMP_MUSIC_CD.getItemName(),
				buildGoodsDetails(itemDetails.getImportedMusicCdCount(), itemDetails.getImportedMusicCd(),
						itemDetails.getImportedMusicCdPrice()));
		return importedGoodsMap;
	}

	@Override
	public Map<String, String> calculate(ItemsPojo itemDetails) {
		Map<String, String> localGoodsMap = this.getLocalGoodsDetails(itemDetails);
		Map<String, String> importedGoodsMap = this.getImportedGoodsDetails(itemDetails);
		localGoodsMap.putAll(importedGoodsMap);
		totalCost = 0.0f;
		Map<String, String> finalMap = new TreeMap<>();
		localGoodsMap.entrySet().stream().forEach(entry -> {
			String itemName = entry.getKey();
			String[] itemDetailsArray = entry.getValue().split(HYPHEN);
			String itemCount = itemDetailsArray[ZERO];
			boolean itemFlag = Boolean.valueOf(itemDetailsArray[TWO]);
			if (itemFlag||(Integer.valueOf(itemCount)>0)) {
				float totalPrice = taxCalculationService.calculateTax(itemName, itemCount, itemDetailsArray[ONE],
						Boolean.valueOf(itemDetailsArray[TWO]));
				finalMap.put(entry.getKey(), itemCount + SPACE + itemName + SPACE + COLON + SPACE + totalPrice + COMMA);
				totalCost += totalPrice;
			}
		});
		if(!CollectionUtils.isEmpty(finalMap)) {
		finalMap.put(TOTAL_SALES_TAX, SALES_TAX + SPACE + COLON + SPACE + taxCalculationService.getSalesTax());
		finalMap.put(TOTAL_COST, TOTAL + SPACE + COLON + SPACE + totalCost);
		}else {
			finalMap.put(TOTAL_COST,EMPTY );	
		}
		return finalMap;

	}

	/**
	 * buildGoodsDetails retrives detail of each item
	 * 
	 * @param itemCount
	 * @param itemFlag
	 * @param originalPrice
	 * @return itemDetail
	 */
	private String buildGoodsDetails(int itemCount, String itemFlag, float originalPrice) {
		StringBuffer itemDetail = new StringBuffer();
		if (Objects.isNull(itemFlag)) {
			return itemDetail.append(String.valueOf(itemCount)).append(HYPHEN).append(originalPrice).append(HYPHEN)
					.append(Boolean.FALSE.toString()).toString();
		}
		return itemDetail.append(String.valueOf(itemCount)).append(HYPHEN).append(originalPrice).append(HYPHEN)
				.append(itemFlag).toString();
	}
}
