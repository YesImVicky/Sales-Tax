package com.application.demo.salestax.service;

import java.util.Map;

import com.application.demo.salestax.enums.ItemsPojo;

/**
 * @author Vignesh
 * @version 1 
 * ItemManagementService manages items
 *
 */
public interface ItemManagementService {
	enum GoodsTypeEnum {
		BOOK("Book"), MUSIC_CD("MusicCD"), CHOCOLATE("Chocolate"), PERFUME("Perfume"), PILLS("HeadachePills"),
		IMP_BOOK("ImportedBook"), IMP_MUSIC_CD("ImportedMusicCD"), IMP_CHOCOLATE("ImportedChocolate"),
		IMP_PERFUME("ImportedPerfume"), IMP_PILLS("ImportedHeadachePills");
		private String itemName;

		private GoodsTypeEnum(String name) {
			itemName = name;
		}

		public String getItemName() {
			return itemName;
		}
	}

	/**
	 * getLocalGoodsDetails retrieves data of localGoods
	 * 
	 * @param itemDetails
	 * @return itemDetailsMap
	 */
	public Map<String, String> getLocalGoodsDetails(ItemsPojo itemDetails);

	/**
	 * getImportedGoodsDetails retrieves data of importedGoods
	 * 
	 * @param itemDetails
	 * @return itemDetailsMap
	 */
	public Map<String, String> getImportedGoodsDetails(ItemsPojo itemDetails);

	/**
	 * calculate method calculates all taxes
	 * 
	 * @param itemDetails
	 * @return itemDetailsMap
	 */
	public Map<String, String> calculate(ItemsPojo itemDetails);

}
