package com.application.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.application.demo.salestax.enums.ItemsPojo;
import com.application.demo.salestax.service.ItemManagementService;

/**
 * @author Vignesh
 * @version 1
 * @since 2018
 */
@Controller
public class HomeController {

	/**
	 * itemManagementService is for maintaining the items
	 */
	@Autowired
	private ItemManagementService itemManagementService;

	/**
	 * start method provides the HomeScreen
	 * 
	 * @return view
	 */
	@RequestMapping("/home")
	public String start() {
		return "index.jsp";
	};

	/**
	 * submit method displays SummaryDetailScreen
	 * @param itemDetails
	 * @return view
	 */
	@RequestMapping("/submit")
	public ModelAndView submit(ItemsPojo itemDetails) {
		Map<String, String> businessMap = itemManagementService.calculate(itemDetails);
		ModelAndView view = new ModelAndView();
		StringBuilder detailString = new StringBuilder();
		businessMap.values().forEach(result -> {
			detailString.append(result).append("\n").append("\n").append("\n").append("\n");
		});
		view.addObject("details", detailString);
		view.setViewName("detailPage.jsp");
		return view;
	};
}
