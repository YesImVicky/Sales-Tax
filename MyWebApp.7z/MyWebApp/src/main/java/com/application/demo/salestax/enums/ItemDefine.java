package com.application.demo.salestax.enums;

/**
 * @author Vignesh
 * @version 1 
 * ItemDefine is Class for taxDetails
 */
public class ItemDefine {
	/**
	 * enum for ItemType
	 */
	public enum ItemType {
		BOOK("book",true, false), 
		MEDICAL("HeadachePills",true, false), 
		FOOD("Chocolate",true, false),
		PERFUME("Perfume",false, false), 
		CD("MusicCD",false, false), 
		IMPORTED_BOOK("ImportedBook",true, true),
		IMPORTED_MEDICAL("ImportedHeadachePills",true, true),
		IMPORTED_FOOD("ImportedChocolate", true, true), 
		IMPORTED_PERFUME("ImportedPerfume",false, true),
		IMPORTED_CD("ImportedMusicCD",false, true);
		private String itemName;
		private boolean isExempted;
		private boolean isImported;

		private ItemType(String name, boolean exepmted, boolean imported) {
			itemName = name;
			isExempted = exepmted;
			isImported = imported;
		}

		public boolean isImported() {
			return isImported;
		}

		public boolean isExempted() {
			return isExempted;
		}
		
		public String itemName() {
			return itemName;
		}

	}
}
