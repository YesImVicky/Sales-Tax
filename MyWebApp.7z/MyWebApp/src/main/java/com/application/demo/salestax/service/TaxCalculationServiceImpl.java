package com.application.demo.salestax.service;

import java.text.DecimalFormat;
import java.text.Format;

import org.springframework.stereotype.Component;

import com.application.demo.salestax.enums.ItemDefine;
import com.application.demo.salestax.enums.TaxDefine.TaxType;

@Component
public class TaxCalculationServiceImpl implements TaxCalculationService {
	/** ROUNDOFF*/
	private static final float ROUNDOFF = 0.05f;
	/** FORMATTER*/
	private static final Format FORMATTER = new DecimalFormat("0.00");
	/** salesTax*/
	private float salesTax;

	@Override
	public float calculateTax(String itemName, String itemCount, String originalPrice, boolean itemFlag) {
		if (itemFlag||Integer.valueOf(itemCount)>0) {
			float tax = getItemTaxType(itemName).getApplicableTax();
			float roundOffValue = roundOffTax(Float.valueOf(originalPrice) * tax);
			float pricePerItem = Float.sum(Float.valueOf(originalPrice), roundOffValue);
			float totalAmountIncludingTax = pricePerItem * Float.valueOf(itemCount);
			if (!Integer.valueOf(itemCount).equals(0)) {
				salesTax += totalAmountIncludingTax -( Float.valueOf(originalPrice)* Float.valueOf(itemCount));
			}
			return totalAmountIncludingTax;
		}
		return 0;
	}

	@Override
	public float getSalesTax() {
		Float totalSalesTax = Float.valueOf(FORMATTER.format(salesTax));
		salesTax = 0.0f;
		return totalSalesTax;
		
	}

	/**
	 * getItemTaxType gets TaxType of each item
	 * @param itemName
	 * @return taxType
	 */
	private TaxType getItemTaxType(String itemName) {
		if (ItemDefine.ItemType.PERFUME.itemName().equals(itemName) || ItemDefine.ItemType.CD.itemName().equals(itemName)) {
			return TaxType.BASIC;
		} else if (ItemDefine.ItemType.IMPORTED_BOOK.itemName().equals(itemName)
				|| ItemDefine.ItemType.IMPORTED_MEDICAL.itemName().equals(itemName)
				|| ItemDefine.ItemType.IMPORTED_FOOD.itemName().equals(itemName)) {
			return TaxType.IMPORTED;
		} else if (ItemDefine.ItemType.IMPORTED_PERFUME.itemName().equals(itemName)
				|| ItemDefine.ItemType.IMPORTED_CD.itemName().equals(itemName)) {
			return TaxType.BOTH;
		}
		return TaxType.NA;
	}
	
	/**
	 * roundOffTax roundsOff the tax
	 * @param amount
	 * @return rounded tax amount
	 */
	private float roundOffTax(float amount) {
		return (float) Math.ceil(amount / ROUNDOFF) * ROUNDOFF;
	}
}
