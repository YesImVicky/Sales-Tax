package com.application.demo.salestax.enums;

import org.springframework.stereotype.Component;

/**
 * @author Vignesh
 * @version 1
 * ItemsPojo is for storing and retrieving data
 */
@Component
public class ItemsPojo {
	public String book;
	public String musicCd;
	public String chocolateBlock;
	public String perfume;
	public String headAchePills;
	public String importedBook;
	public String importedMusicCd;
	public String importedChocolateBlock;
	public String importedPerfume;
	public String importedHeadAchePills;
	public int bookCount;
	public int musicCdCount;
	public int chocolateBlockCount;
	public int perfumeCount;
	public int headAchePillsCount;
	public int importedBookCount;
	public int importedMusicCdCount;
	public int importedChocolateBlockCount;
	public int importedPerfumeCount;
	public int importedHeadAchePillsCount;
	public float bookPrice;
	public float musicCdPrice;
	public float chocolateBlockPrice;
	public float perfumePrice;
	public float headAchePillsPrice;
	public float importedBookPrice;
	public float importedMusicCdPrice;
	public float importedChocolateBlockPrice;
	public float importedPerfumePrice;
	public float importedHeadAchePillsPrice;

	public float getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(float bookPrice) {
		this.bookPrice = bookPrice;
	}

	public float getMusicCdPrice() {
		return musicCdPrice;
	}

	public void setMusicCdPrice(float musicCdPrice) {
		this.musicCdPrice = musicCdPrice;
	}

	public float getChocolateBlockPrice() {
		return chocolateBlockPrice;
	}

	public void setChocolateBlockPrice(float chocolateBlockPrice) {
		this.chocolateBlockPrice = chocolateBlockPrice;
	}

	public float getPerfumePrice() {
		return perfumePrice;
	}

	public void setPerfumePrice(float perfumePrice) {
		this.perfumePrice = perfumePrice;
	}

	public float getHeadAchePillsPrice() {
		return headAchePillsPrice;
	}

	public void setHeadAchePillsPrice(float headAchePillsPrice) {
		this.headAchePillsPrice = headAchePillsPrice;
	}

	public float getImportedBookPrice() {
		return importedBookPrice;
	}

	public void setImportedBookPrice(float importedBookPrice) {
		this.importedBookPrice = importedBookPrice;
	}

	public float getImportedMusicCdPrice() {
		return importedMusicCdPrice;
	}

	public void setImportedMusicCdPrice(float importedMusicCdPrice) {
		this.importedMusicCdPrice = importedMusicCdPrice;
	}

	public float getImportedChocolateBlockPrice() {
		return importedChocolateBlockPrice;
	}

	public void setImportedChocolateBlockPrice(float importedChocolateBlockPrice) {
		this.importedChocolateBlockPrice = importedChocolateBlockPrice;
	}

	public float getImportedPerfumePrice() {
		return importedPerfumePrice;
	}

	public void setImportedPerfumePrice(float importedPerfumePrice) {
		this.importedPerfumePrice = importedPerfumePrice;
	}

	public float getImportedHeadAchePillsPrice() {
		return importedHeadAchePillsPrice;
	}

	public void setImportedHeadAchePillsPrice(float importedHeadAchePillsPrice) {
		this.importedHeadAchePillsPrice = importedHeadAchePillsPrice;
	}

	public void setImportedHeadAchePillsPrice(int importedHeadAchePillsPrice) {
		this.importedHeadAchePillsPrice = importedHeadAchePillsPrice;
	}

	public int getImportedHeadAchePillsCount() {
		return importedHeadAchePillsCount;
	}

	public void setImportedHeadAchePillsCount(int importedHeadAchePillsCount) {
		this.importedHeadAchePillsCount = importedHeadAchePillsCount;
	}

	public String getBook() {
		return book;
	}

	public void setBook(String book) {
		this.book = book;
	}

	public String getMusicCd() {
		return musicCd;
	}

	public void setMusicCd(String musicCd) {
		this.musicCd = musicCd;
	}

	public String getChocolateBlock() {
		return chocolateBlock;
	}

	public void setChocolateBlock(String chocolateBlock) {
		this.chocolateBlock = chocolateBlock;
	}

	public String getPerfume() {
		return perfume;
	}

	public void setPerfume(String perfume) {
		this.perfume = perfume;
	}

	public String getHeadAchePills() {
		return headAchePills;
	}

	public void setHeadAchePills(String headAchePills) {
		this.headAchePills = headAchePills;
	}

	public String getImportedBook() {
		return importedBook;
	}

	public void setImportedBook(String importedBook) {
		this.importedBook = importedBook;
	}

	public String getImportedMusicCd() {
		return importedMusicCd;
	}

	public void setImportedMusicCd(String importedMusicCd) {
		this.importedMusicCd = importedMusicCd;
	}

	public String getImportedChocolateBlock() {
		return importedChocolateBlock;
	}

	public void setImportedChocolateBlock(String importedChocolateBlock) {
		this.importedChocolateBlock = importedChocolateBlock;
	}

	public String getImportedPerfume() {
		return importedPerfume;
	}

	public void setImportedPerfume(String importedPerfume) {
		this.importedPerfume = importedPerfume;
	}

	public String getImportedHeadAchePills() {
		return importedHeadAchePills;
	}

	public void setImportedHeadAchePills(String importedHeadAchePills) {
		this.importedHeadAchePills = importedHeadAchePills;
	}

	public int getBookCount() {
		return bookCount;
	}

	public void setBookCount(int bookCount) {
		this.bookCount = bookCount;
	}

	public int getMusicCdCount() {
		return musicCdCount;
	}

	public void setMusicCdCount(int musicCdCount) {
		this.musicCdCount = musicCdCount;
	}

	public int getChocolateBlockCount() {
		return chocolateBlockCount;
	}

	public void setChocolateBlockCount(int chocolateBlockCount) {
		this.chocolateBlockCount = chocolateBlockCount;
	}

	public int getPerfumeCount() {
		return perfumeCount;
	}

	public void setPerfumeCount(int perfumeCount) {
		this.perfumeCount = perfumeCount;
	}

	public int getHeadAchePillsCount() {
		return headAchePillsCount;
	}

	public void setHeadAchePillsCount(int headAchePillsCount) {
		this.headAchePillsCount = headAchePillsCount;
	}

	public int getImportedBookCount() {
		return importedBookCount;
	}

	public void setImportedBookCount(int importedBookCount) {
		this.importedBookCount = importedBookCount;
	}

	public int getImportedMusicCdCount() {
		return importedMusicCdCount;
	}

	public void setImportedMusicCdCount(int importedMusicCdCount) {
		this.importedMusicCdCount = importedMusicCdCount;
	}

	public int getImportedChocolateBlockCount() {
		return importedChocolateBlockCount;
	}

	public void setImportedChocolateBlockCount(int importedChocolateBlockCount) {
		this.importedChocolateBlockCount = importedChocolateBlockCount;
	}

	public int getImportedPerfumeCount() {
		return importedPerfumeCount;
	}

	public void setImportedPerfumeCount(int importedPerfumeCount) {
		this.importedPerfumeCount = importedPerfumeCount;
	}
}
